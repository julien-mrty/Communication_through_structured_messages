from setuptools import setup, find_packages

setup(
    name='messaging',
    version='0.1',
    description='Interface front de messagerie en TurboGears2',
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        'TurboGears2',
        'gearbox',
        'Paste',
        'SQLAlchemy',
        'zope.sqlalchemy',
        'mako',
    ],
    package_data={
        'messaging': [
            'templates/**/*.mako',
            'public/static/css/*.css',
            'public/static/js/*.js',
        ],
    },
    entry_points={
        'paste.app_factory': [
            'main = messaging.config.middleware:make_app',
        ],
    },
)

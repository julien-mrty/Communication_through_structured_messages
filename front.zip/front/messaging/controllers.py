from tg import expose, redirect
from tg.controllers import TGController


class UIController(TGController):
    @expose('ui.index')
    def ui(self):
        return {}


class RootController(TGController):
    @expose()
    def index(self):
        redirect('/ui')

    @expose('messaging.templates.ui.index')
    def ui(self):
        return {}

from tg import MinimalApplicationConfigurator
from messaging.controllers import RootController
import os

def make_app(global_conf, **app_conf):
    here = os.path.abspath(os.path.dirname(__file__))

    config = MinimalApplicationConfigurator()
    config.update_blueprint({
        'root_controller': RootController(),
        'modules': ['messaging'],
        'renderers': ['mako', 'json'],
        'default_renderer': 'mako',
        'serve_static': True,
        'static_files': {
            '/static': 'public/static'
        },
        'paths': {
            'templates': [
                os.path.join(here, '..', 'templates')
            ]
        }
    })

    return config.make_wsgi_app()

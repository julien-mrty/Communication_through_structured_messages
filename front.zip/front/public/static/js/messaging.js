document.addEventListener('DOMContentLoaded', () => {
  const fakeThreads = [
    { id: 1, title: 'Projet F1 Academy', updated_at: '2025-05-20 10:15' },
    { id: 2, title: 'Partenariat 4L Trophy', updated_at: '2025-05-19 17:42' }
  ];

  const messages = {
    1: [
      { content: 'Salut, on valide le budget média ?', created_at: '2025-05-20 10:00' },
      { content: 'Oui, je prépare le kit presse !', created_at: '2025-05-20 10:10' }
    ],
    2: [
      { content: 'On imprime les flyers demain ? 🤔', created_at: '2025-05-19 17:30' }
    ]
  };

  const threadList = document.getElementById('thread-list');
  const messageArea = document.getElementById('message-area');

  threadList.innerHTML = fakeThreads.map(t =>
    `<li class="list-group-item"><a href="#" data-id="${t.id}">${t.title}</a></li>`
  ).join('');

  threadList.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', e => {
      e.preventDefault();
      const id = link.dataset.id;
      const selected = fakeThreads.find(t => t.id == id);
      messageArea.innerHTML = `
        <h3>${selected.title}</h3>
        <div>${messages[id].map(m => `
          <div class="card my-2"><div class="card-body">
            <p>${m.content}</p><small>${m.created_at}</small>
          </div></div>
        `).join('')}</div>
      `;
    });
  });

  document.getElementById('new-thread-btn').addEventListener('click', () => {
    alert('Simulation : création de conversation désactivée 🛠️');
  });
});
